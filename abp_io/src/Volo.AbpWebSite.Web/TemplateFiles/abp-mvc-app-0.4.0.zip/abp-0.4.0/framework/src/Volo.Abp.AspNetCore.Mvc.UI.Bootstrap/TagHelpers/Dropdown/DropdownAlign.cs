﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Dropdown
{
    public enum DropdownAlign
    {
        Left,
        Right
    }
}