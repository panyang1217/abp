﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Dropdown
{
    public enum DropdownStyle
    {
        Single,
        Split
    }
}