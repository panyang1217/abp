﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Form
{
    public class FormGroupItem
    {
        public string HtmlContent { get; set; }

        public int Order { get; set; }
    }
}