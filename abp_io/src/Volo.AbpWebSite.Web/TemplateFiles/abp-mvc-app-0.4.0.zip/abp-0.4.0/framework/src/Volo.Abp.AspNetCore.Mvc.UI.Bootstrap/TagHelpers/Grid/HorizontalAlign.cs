﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Grid
{
    public enum HorizontalAlign
    {
        Default,
        Start,
        Center,
        Around,
        Between,
        End
    }
}