﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Grid
{
    public enum VerticalAlign
    {
        Default,
        Start,
        Center,
        End
    }
}