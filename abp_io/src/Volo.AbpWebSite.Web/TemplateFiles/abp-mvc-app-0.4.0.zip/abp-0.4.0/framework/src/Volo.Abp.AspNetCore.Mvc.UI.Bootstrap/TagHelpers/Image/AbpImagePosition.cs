﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Image
{
    public enum AbpImagePosition
    {
        Default,
        Right,
        Left,
        Center
    }
}