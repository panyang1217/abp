﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.ListGroup
{
    public enum AbpListItemTagType
    {
        Default,
        Link,
        Button
    }
}