﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Table
{
    public enum AbpThScope
    {
        Default,
        Row,
        Column
    }
}