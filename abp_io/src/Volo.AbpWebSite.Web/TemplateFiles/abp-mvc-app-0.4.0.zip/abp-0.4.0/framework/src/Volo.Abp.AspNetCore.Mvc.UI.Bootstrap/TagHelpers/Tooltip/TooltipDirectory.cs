﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bootstrap.TagHelpers.Tooltip
{
    public enum TooltipDirectory
    {
        Default,
        Right,
        Left,
        Bottom,
        Top
    }
}