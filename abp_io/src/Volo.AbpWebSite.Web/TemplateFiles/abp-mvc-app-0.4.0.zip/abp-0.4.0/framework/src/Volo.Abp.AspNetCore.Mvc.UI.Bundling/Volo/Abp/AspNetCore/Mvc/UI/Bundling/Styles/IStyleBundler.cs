namespace Volo.Abp.AspNetCore.Mvc.UI.Bundling.Styles
{
    public interface IStyleBundler : IBundler
    {

    }
}