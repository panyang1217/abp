﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Bundling.TagHelpers
{
    public interface IBundleTagHelper
    {
        string GetNameOrNull();
    }
}