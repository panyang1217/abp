namespace Volo.Abp.AspNetCore.Mvc.UI.Minification.Scripts
{
    public interface IJavascriptMinifier : IMinifier
    {

    }
}