﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Theme.Shared.Bundling
{
    public class StandardBundles
    {
        public static class Styles
        {
            public static string Global = "Global";
        }

        public static class Scripts
        {
            public static string Global = "Global";
        }
    }
}
