﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Alerts
{
    public interface IAlertManager
    {
        AlertList Alerts { get; }
    }
}
