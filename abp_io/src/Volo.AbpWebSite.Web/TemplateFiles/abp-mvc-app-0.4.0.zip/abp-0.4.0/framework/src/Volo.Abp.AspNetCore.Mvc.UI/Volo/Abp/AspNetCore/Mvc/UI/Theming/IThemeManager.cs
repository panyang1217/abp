﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Theming
{
    public interface IThemeManager
    {
        ITheme CurrentTheme { get; }
    }
}
