﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Theming
{
    public interface IThemeSelector
    {
        ThemeInfo GetCurrentThemeInfo();
    }
}