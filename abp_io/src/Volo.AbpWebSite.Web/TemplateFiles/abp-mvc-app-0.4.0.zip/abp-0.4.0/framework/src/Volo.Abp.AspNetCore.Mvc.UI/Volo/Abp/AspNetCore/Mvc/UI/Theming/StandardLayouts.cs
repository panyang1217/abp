﻿namespace Volo.Abp.AspNetCore.Mvc.UI.Theming
{
    public static class StandardLayouts
    {
        public const string Application = "Application";
        public const string Account = "Account";
        public const string Empty = "Empty";
    }
}
