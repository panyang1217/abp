using Microsoft.AspNetCore.Mvc.ApplicationModels;

namespace Volo.Abp.AspNetCore.Mvc.Conventions
{
    public interface IAbpServiceConvention : IApplicationModelConvention
    {
    }
}